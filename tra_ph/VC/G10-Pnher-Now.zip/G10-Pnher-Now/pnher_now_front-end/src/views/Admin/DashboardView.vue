<script setup lang="ts">
import AdminLayout from '@/Components/Layouts/AdminLayout.vue'
</script>
<template>
  <AdminLayout
    ><div class="flex flex-col bg-white justify-center rounded-lg h-[calc(100vh-150px)]">
      <div class="text-center">
        <h1 class="text-4xl md:text-6xl font-bold mb-4">Welcome to Dashboard</h1>
        <p class="text-lg md:text-2xl mb-8">Your journey to excellence starts here.</p>
        <p>Join Us Today and Get Started</p>
      </div>
    </div>
  </AdminLayout>
</template>
