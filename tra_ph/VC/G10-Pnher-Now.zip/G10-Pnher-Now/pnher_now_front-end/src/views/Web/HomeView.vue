<script setup lang="ts" >
import WebLayout from '@/Components/Layouts/WebLayout.vue'
</script>

<template>
  <WebLayout
    ><div
      class="max-w-2xl mt-2 rounded px-4 py-10 m-auto bg-white sm:px-8 dark:bg-gray-800 ring-1 ring-gray-200 dark:ring-gray-700"
    >
      <div class="text-center">
        <p class="text-lg md:text-2xl mb-8">Your journey to excellence starts here.</p>
        <p>Join Us Today and Get Started</p>
      </div>
    </div>
  </WebLayout>
</template>
