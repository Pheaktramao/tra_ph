<script setup lang="ts"></script>

<template>
  <RouterView />
</template>


<!-- <script> -->
 
// export default {
//   data() {
//     return {
//       options: {
//         animationEnabled: true,
//         title: {
//           text: "TikTok User Demographics - US"
//         },
//         axisY: {
//           includeZero: true,
//           suffix: "%"
//         },
//         data: [{
//           yValueFormatString: "#,###.##'%'",
//           dataPoints: [
//             {label: "10-19", y: 25 },
//             {label: "20-29", y: 22.4 },
//             {label: "30-39", y: 21.7 },
//             {label: "40-49", y: 20.3 },
//             {label: "50+", y: 11 }
//           ]
//         }]
//       }
//     }    
//   }
// }
<!-- // </script> -->
<!-- // <template>
//   <CanvasJSChart :options="options"/>
// </template>    -->
