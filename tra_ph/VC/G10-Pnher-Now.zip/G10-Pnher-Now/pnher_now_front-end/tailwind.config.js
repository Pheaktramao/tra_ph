module.exports = {
  content: ['./src/**/*.{html,js,ts,vue}'],
  theme: {
    extend: {},
  },
  plugins: [],
};
